package com.animeshpatni.newsgateway;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class MainActivity extends AppCompatActivity
{
    private ArrayList<String> it = new ArrayList<>();
    private myadapter adap;
    private Menu menu;
    private ViewPager viewPager;
    private List<Fragment> fragmentList;
    private ActionBarDrawerToggle drawerToggle;
    private ListView listView;
    private recieve_news newsgetter1;
    private ArrayList<String> source = new ArrayList<>();
    private ArrayList<String> category = new ArrayList<>();
    private ArrayList<String> newsid = new ArrayList<>();
    private ArrayList<String> authorList = new ArrayList<>();
    private boolean f = false;
    private String cat = "null";
    String sur = "";
    int ac=0 ,a=0 ,ind = 0;
    static final String EXTRA = "DATA_EXTRA1";
    static final String ACTION = "ACTION_NEWS_STORY";
    private DrawerLayout drawerLayout;
    NetworkInfo networkInfo;
    private static final String TAG = "MA";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        drawerLayout = findViewById(R.id.drawer_main);
        listView = findViewById(R.id.drawer);
        Log.d(TAG, "onCreate: Intializing");
        listView.setAdapter(new ArrayAdapter<>(this, R.layout.list_view, it));
        listView.setOnItemClickListener(new ListView.OnItemClickListener(){
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                viewPager.setBackground(null);
                selectedItem(position);
            }
        });
        drawerToggle = new ActionBarDrawerToggle(this,drawerLayout,R.string.open,R.string.close);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        Log.d(TAG, "onCreate: Enable frawer");
        fragmentList = getFragments();
        adap = new myadapter(getSupportFragmentManager());
        viewPager = findViewById(R.id.view_pager_);
        //ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        //networkInfo = cm.getActiveNetworkInfo();
        //if (networkInfo != null && (networkInfo.isConnectedOrConnecting()))
        //{
        //    new MyAsync(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,"all");
        //}
        //else
        //{
        //    AlertDialog.Builder b = new AlertDialog.Builder(this);
        //    b.setTitle("No Internet Connection");
        //    final TextView textView = new TextView(this);
        //    textView.setText("News Cannot Be Loaded Without Internet Connection");
        //    textView.setGravity(Gravity.CENTER_HORIZONTAL);
        //    b.setView(textView);
        //    AlertDialog alertDialog = b.create();
        //    alertDialog.show();
        //}
        viewPager.setAdapter(adap);
        viewPager.setBackgroundResource(R.drawable.breaking);
        Intent intent = new Intent(MainActivity.this,service_news.class);
        Log.d(TAG, "onCreate: HERE INTENT");
        startService(intent);
        newsgetter1 = new recieve_news();
        IntentFilter intentFilter = new IntentFilter(ACTION);
        Log.d(TAG, "onCreate: Intent filter");
        registerReceiver(newsgetter1,intentFilter);
        new MyAsync(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,"all");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        outState.putString("cate", cat);
        outState.putInt("count", ac);
        outState.putInt("index", viewPager.getCurrentItem());
        super.onSaveInstanceState(outState);
    }
    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        drawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        drawerToggle.onConfigurationChanged(newConfig);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState)
    {
        String hi = savedInstanceState.getString("cate");
        if (savedInstanceState.getInt("count") != 0) {
            if (!(hi.equals("null"))) {
                new MyAsync(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, "Category", hi);
            }
            a = savedInstanceState.getInt("count");
            ind = savedInstanceState.getInt("index");
            viewPager.setBackground(null);
            dothefrags();
        }
         else {
                viewPager.setBackgroundResource(R.drawable.breaking);
        }
        super.onRestoreInstanceState(savedInstanceState);
    }
    private void dothefrags()
    {
        int i=0;
        while(i<adap.getCount())
        {
            adap.notifyChangeInPosition(i);
            i++;
        }
        fragmentList.clear();
        int j=0;
        while(j<a)
        {
            fragmentList.add(fragments_news.NewInstance(j));
            j++;
        }
        adap.notifyDataSetChanged();
        viewPager.setCurrentItem(ind);
    }
    private void selectedItem(int pos)
    {
        it = source;
        setTitle(it.get(pos));
        Log.d(TAG, "selectedItem: "+it);
        sur = newsid.get(pos);
        Intent intent = new Intent();
        Log.d(TAG, "selectedItem: "+pos);
        intent.setAction(service_news.ACTION_MSG);
        intent.putExtra(EXTRA,sur);
        Log.d(TAG, "selectedItem: "+sur);
        sendBroadcast(intent);
        drawerLayout.closeDrawer(listView);
    }

    private List<Fragment> getFragments()
    {
        List<Fragment> fragmentList1 = new ArrayList<Fragment>();
        return fragmentList1;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.empty_menu,menu);
        this.menu = menu;
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(drawerToggle.onOptionsItemSelected(item)==true)
            return true;
        if(item.toString().equals("all")==true)
            new MyAsync(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,"all");
        else
        {
            cat = item.toString();
            new MyAsync(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,"Category",item.toString());
        }
        return true;
    }

    @Override
    protected void onDestroy()
    {
        unregisterReceiver(newsgetter1);
        Log.d(TAG, "onDestroy: DEAD");
        Intent intent = new Intent(MainActivity.this,service_news.class);
        stopService(intent);
        super.onDestroy();
    }

    private class myadapter extends FragmentPagerAdapter
    {
        private long base = 0;

        @Override
        public long getItemId(int position) {
            return base+position;
        }

        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        @Override
        public int getItemPosition(Object object) {
            return POSITION_NONE;
        }

        public void notifyChangeInPosition(int n) {
            base += getCount() + n;
        }

        public myadapter(FragmentManager fm) {
            super(fm);
        }
    }

    class recieve_news extends BroadcastReceiver
    {
        @Override
        public void onReceive(Context context, Intent intent)
        {
            if(intent.getAction().equals(ACTION) && intent.hasExtra(service_news.SERVICE_DATA))
            {
                authorList = intent.getStringArrayListExtra(service_news.SERVICE_DATA);
                ac = authorList.size();
                fragmentList.clear();
                int i=0;
                while(i<ac)
                {
                    fragmentList.add(fragments_news.NewInstance(i));
                    i++;
                }
                adap.notifyDataSetChanged();
                viewPager.setCurrentItem(0);
            }
        }
    }
    public void Source(ArrayList<String> so,ArrayList<String> ca,ArrayList<String> id)
    {
        source.clear();
        category.clear();
        source = so;
        Log.d(TAG, "Source: here");
        category = ca;
        newsid = id;
        Collections.sort(category);
        if(f == false)
        {
            menu.add(R.menu.empty_menu,Menu.NONE,0,"all");
            int i=0;
            while(i<category.size())
            {
                menu.add(R.menu.empty_menu,Menu.NONE,0,category.get(i));
                i++;
            }
            f = true;
        }
        listView.setAdapter(new ArrayAdapter<>(this,R.layout.list_view,source));
    }
}
