package com.animeshpatni.newsgateway;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class MyAsyncArticle extends AsyncTask<String,Void,String>
{
    private final String mykey = "95123dc5c75942f1b3425d34becf6083";
    private final String NewsURL = "https://newsapi.org/v1/articles?";
    private service_news serviceNews;
    public HashMap<String, ArrayList<String>> arrayListHashMap = new HashMap<>();
    private ArrayList<String> article = new ArrayList<>();
    private ArrayList<String> author = new ArrayList<>();
    private ArrayList<String> title = new ArrayList<>();
    private ArrayList<String> description = new ArrayList<>();
    private static final String TAG = "MyAsyncArticle";
    private ArrayList<String> url = new ArrayList<>();
    private ArrayList<String> time = new ArrayList<>();
    private ArrayList<String> website = new ArrayList<>();
    private Bitmap bitmap1;
    private String s = "";

    @Override
    protected String doInBackground(String... strings)
    {
        s = strings[0];
        Uri.Builder builder = Uri.parse(NewsURL).buildUpon();
        builder.appendQueryParameter("source",strings[0]);
        builder.appendQueryParameter("apiKey",mykey);
        String urluse = builder.build().toString();
        StringBuilder stringBuilder = new StringBuilder();
        try
        {
            URL url1 = new URL(urluse);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url1.openConnection();
            httpURLConnection.setRequestMethod("GET");
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String s1;
            while((s1 = bufferedReader.readLine())!=null)
            {
                stringBuilder.append(s1);
                stringBuilder.append('\n');
            }
        }
        catch (Exception e)
        {
            return null;
        }
        parser(stringBuilder.toString());
        return null;
    }
    private void parser(String s2)
    {
        settergetter.arrayList.clear();
        String string="";
        String string2;
        try
        {
            JSONObject jsonObject = new JSONObject(s2);
            JSONArray jsonArray = (JSONArray) jsonObject.get("articles");
            int i=0;
            while(i<jsonArray.length())
            {
                article.add(jsonArray.getString(i));
                JSONObject jsonObject1 = new JSONObject(article.get(i));
                Log.d(TAG, "parser: adding vals");
                title.add(jsonObject1.getString("title"));
                author.add(jsonObject1.getString("author"));
                description.add((jsonObject1.getString("description")));
                Log.d(TAG, "parser: description added");
                url.add(jsonObject1.getString("urlToImage"));
                website.add(jsonObject1.getString("url"));
                try
                {
                    if(jsonObject1.getString("publishedAt").equals("null")==false)
                    {
                        string ="";
                        if(jsonObject1.getString("publishedAt").contains("+00:00"))
                        {
                            string2 = jsonObject1.getString("publishedAt").replace("+00:00","Z");
                            Log.d(TAG, "parser: "+string2);
                        }
                        else
                        {
                            string2 = jsonObject1.getString("publishedAt");
                            Log.d(TAG, "parser: "+string2);
                        }
                        try
                        {
                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
                            String done = "right";
                            SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("MMMM dd, yyyy HH:mm");
                            done = "right + one";
                            Date date1 = simpleDateFormat.parse(string2);
                            Log.d(TAG, "parser: "+done);
                            string = simpleDateFormat1.format(date1);
                        }
                        catch (Exception e)
                        {
                            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
                            String eeee= "right twice";
                            Log.d(TAG, "parser: "+eeee);
                            SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("MMMM dd, yyyy HH:mm");
                            Log.d(TAG, "parser: "+eeee);
                            Date date1 = simpleDateFormat.parse(string2);
                            String eeee1 = "right thrice";
                            string = simpleDateFormat1.format(date1);
                        }
                        time.add(string);
                    }
                    else
                    {
                        string = "null";
                    }
                    String imageURL = jsonObject1.getString("urlToImage");
                    if(s.equals("buzzfeed"))
                    {
                        String newurl = imageURL.replace("http:","https:");
                        Log.d(TAG, "parser: Buzzfeed selected");
                        java.net.URL url1 = new java.net.URL(newurl);
                        HttpURLConnection httpURLConnection1 = (HttpURLConnection)url1.openConnection();
                        httpURLConnection1.setDoInput(true);
                        Log.d(TAG, "parser: "+newurl);
                        httpURLConnection1.connect();
                        InputStream inputStream1 = httpURLConnection1.getInputStream();
                        bitmap1 = BitmapFactory.decodeStream(inputStream1);
                    }
                    else
                    {
                        java.net.URL url1 = new java.net.URL(imageURL);
                        HttpURLConnection httpURLConnection1 = (HttpURLConnection)url1.openConnection();
                        Log.d(TAG, "parser: everything else");
                        httpURLConnection1.setDoInput(true);
                        httpURLConnection1.connect();
                        Log.d(TAG, "parser: connected");
                        InputStream inputStream1 = httpURLConnection1.getInputStream();
                        bitmap1 = BitmapFactory.decodeStream(inputStream1);
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
                Log.d(TAG, "parser: adding everything to addnew");
                settergetter.adding(jsonObject1.getString("title"),jsonObject1.getString("author"), bitmap1,jsonObject1.getString("description"),jsonArray.length(),string, jsonObject1.getString("url"));
                i++;
            }
            arrayListHashMap.put("Author",author);
            arrayListHashMap.put("Title",title);
            String sure = "inputing data";
            arrayListHashMap.put("Description",description);
            arrayListHashMap.put("URL",url);
            sure  = "inputing data 1";
            arrayListHashMap.put("Time",time);
            Log.d(TAG, "parser: "+sure);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    public MyAsyncArticle(service_news serviceNews1)
    {
        serviceNews = serviceNews1;
    }

    @Override
    protected void onPostExecute(String s) {
        serviceNews.setArticle(arrayListHashMap);
    }
}
