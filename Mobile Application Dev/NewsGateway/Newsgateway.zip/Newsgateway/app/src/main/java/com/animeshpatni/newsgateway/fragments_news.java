package com.animeshpatni.newsgateway;

import android.support.v4.app.Fragment;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class fragments_news extends Fragment
{
    public static final String EXTRA = "EXTRA_MESSAGE";
    private ImageView imageView;
    public static String index;
    View view;
    private static final String TAG = "fragments_news";
    public static final Fragment NewInstance(int m)
    {
        fragments_news f = new fragments_news();
        Bundle bundle = new Bundle(1);
        bundle.putInt(EXTRA,m);
        index = Integer.toString(m);
        f.setArguments(bundle);
        return f;
    }
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.new_fragment,container,false);
        int m;
        m = getArguments().getInt(EXTRA);
        TextView textView = view.findViewById(R.id.headline);
        if(settergetter.get(getShowmIndex()).getT().equals("null"))
        {
            textView.setText("");
        }
        else if(!settergetter.get(getShowmIndex()).getT().equals("null"))
        {
            textView.setText(settergetter.get(getShowmIndex()).getT());
        }
        TextView textView1 = view.findViewById(R.id.author);
        if(settergetter.get(getShowmIndex()).getA().equals("null"))
        {
            textView1.setText("");
        }
        else if(!settergetter.get(getShowmIndex()).getA().equals("null"))
        {
            textView1.setText(settergetter.get(getShowmIndex()).getA());
        }
        TextView textView2 = view.findViewById(R.id.desc);
        if(settergetter.get(getShowmIndex()).getDesc().equals("null"))
        {
            textView2.setText("");
        }
        else if(!settergetter.get(getShowmIndex()).getDesc().equals("null"))
        {
            textView2.setText(settergetter.get(getShowmIndex()).getDesc());
        }
        textView2.setMovementMethod(new ScrollingMovementMethod());
        TextView textView3 = view.findViewById(R.id.counter);
        textView3.setText(Integer.toString(m+1)+" of "+settergetter.get(getShowmIndex()).getC());
        TextView textView4 = view.findViewById(R.id.date);
        if(settergetter.get(getShowmIndex()).getTime().equals("null")==false)
            textView4.setText(settergetter.get(getShowmIndex()).getTime());
        else
            textView4.setText("");
        textView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Uri uri = Uri.parse(settergetter.get(getShowmIndex()).getUrl());
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        imageView = view.findViewById(R.id.photo);
        Bitmap bitmap = settergetter.get(getShowmIndex()).getBitmap();
        imageView.setImageBitmap(bitmap);
        imageView.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Uri uri = Uri.parse(settergetter.get(getShowmIndex()).getUrl());
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        textView2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Uri uri = Uri.parse(settergetter.get(getShowmIndex()).getUrl());
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }
        });
        return view;
    }

    public int getShowmIndex()
    {
        return getArguments().getInt(EXTRA,0);
    }
}
