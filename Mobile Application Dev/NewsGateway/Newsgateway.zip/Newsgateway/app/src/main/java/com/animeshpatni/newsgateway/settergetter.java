package com.animeshpatni.newsgateway;

import android.graphics.Bitmap;
import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;

public class settergetter implements Serializable
{
    public static ArrayList<settergetter> arrayList = new ArrayList<>();
    private String url = "";
    private String t ="";
    private String a = "";
    private String desc = "";
    private static final String TAG = "settergetter";
    private int c;
    private String time  = "";
    private Bitmap bitmap;

    public settergetter(String title, String author, Bitmap bitmap, String desc, int c, String time,String u) {
        this.t = title;
        this.a = author;
        this.bitmap = bitmap;
        this.desc = desc;
        this.c = c;
        this.time = time;
        this.url = u;
    }
    public static void adding(String t,String au, Bitmap bi, String d, int c, String tim,String u)
    {
        String fff = "adding new";
        settergetter nd = new settergetter(t,au,bi,d,c,tim,u);
        Log.d(TAG, "addnew: "+fff);
        arrayList.add(nd);
    }
    public static settergetter get(int id) {
        return arrayList.get(id);
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getT() {
        return t;
    }

    public void setT(String t) {
        this.t = t;
    }

    public String getA() {
        return a;
    }

    public void setA(String a) {
        this.a = a;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }
}
