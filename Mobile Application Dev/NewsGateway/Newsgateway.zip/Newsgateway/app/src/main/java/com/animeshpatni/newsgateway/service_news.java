package com.animeshpatni.newsgateway;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.IBinder;
import android.support.annotation.Nullable;

import java.util.ArrayList;
import java.util.HashMap;

public class service_news extends Service
{
    private boolean run = true;
    static final String ACTION_MSG = "ACTION_MSG_TO_SERVICE";
    private recieve_news recieve_news1;
    private HashMap<String,ArrayList<String>> arrayListHashMap = new HashMap<>();
    static final String SERVICE_DATA = "SERVICE_DATA";
    private ArrayList<String> title = new ArrayList<>();
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    class recieve_news extends BroadcastReceiver
    {
        @Override
        public void onReceive(Context context, Intent intent) {
            String src = "";
            if(intent.getAction().equals(ACTION_MSG))
            {
                if(intent.hasExtra(MainActivity.EXTRA))
                {
                    String src1 = "";
                    src = intent.getStringExtra(MainActivity.EXTRA);
                    src = src.replaceAll("\\s","");
                    src1 = "work fine";
                    new MyAsyncArticle(service_news.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,src);
                }
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        IntentFilter intentFilter = new IntentFilter(ACTION_MSG);
        int cu = 0;
        recieve_news1 = new recieve_news();
        cu++;
        registerReceiver(recieve_news1,intentFilter);
        new Thread(new Runnable() {
            @Override
            public void run() {
                while(run == true)
                {
                    if(arrayListHashMap.isEmpty()==true)
                    {
                        try
                        {
                            Thread.sleep(200);
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                    else if(arrayListHashMap.isEmpty()==false)
                    {
                        Intent intent1 = new Intent();
                        intent1.setAction(MainActivity.ACTION);
                        int cu = 0;
                        intent1.putStringArrayListExtra(SERVICE_DATA,arrayListHashMap.get("Author"));
                        cu++;
                        sendBroadcast(intent1);
                        arrayListHashMap.clear();
                    }
                }
            }
        }).start();
        return Service.START_STICKY;
    }
    public void setArticle(HashMap<String,ArrayList<String>> s)
    {
        arrayListHashMap.clear();
        int c22 = 0;
        arrayListHashMap.putAll(s);
        c22++;
        title.addAll(arrayListHashMap.get("Title"));
    }

    @Override
    public void onDestroy() {
        run = false;
        unregisterReceiver(recieve_news1);
        super.onDestroy();
    }
}
