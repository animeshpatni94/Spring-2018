package com.animeshpatni.multinotepad;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

/**
 * Created by anime on 08-02-2018.
 */

public class adapter extends RecyclerView.Adapter<viewholder>
{
    private List<newnote> list;
    private MainActivity ma1;


    public adapter(List<newnote> notes, MainActivity main)
    {
        this.list = notes;
        this.ma1 = main;
    }

    public void updateList(List<newnote> list)
    {
        this.list.clear();
        this.list.addAll(list);
        notifyDataSetChanged();
    }

    @Override
    public viewholder onCreateViewHolder(ViewGroup view, int i)
    {
        View v = LayoutInflater.from(view.getContext()).inflate(R.layout.card_view, view, false);
        v.setOnClickListener(ma1);
        v.setOnLongClickListener(ma1);
        return new viewholder(v);
    }

    @Override
    public void onBindViewHolder(viewholder holder, int pos)
    {
        holder.title.setText(this.list.get(pos).getTitle());
        String str = this.list.get(pos).getNote();
        holder.dt.setText(this.list.get(pos).getDatetime());
        if (str.length()>80) {str = str.substring(0,79)+"...";}
        holder.note.setText(str);
    }

    @Override
    public int getItemCount()
    {
        return this.list.size();
    }
}
