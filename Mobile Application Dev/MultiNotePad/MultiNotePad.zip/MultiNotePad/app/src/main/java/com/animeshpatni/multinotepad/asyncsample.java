package com.animeshpatni.multinotepad;

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Created by anime on 10-02-2018.
 */

public class asyncsample extends AsyncTask<String, Integer, String> {

    private MainActivity ma;

    public asyncsample(MainActivity main)
    {
        ma = main;
    }
    @Override
    protected void onPostExecute(String s)
    {
        ArrayList<newnote> list = readjson(s);
        ma.getasyncdata(list);
    }

    private ArrayList<newnote> readjson(String s) {
        ArrayList<newnote> notess = new ArrayList<>();

        try {
            JSONArray list = new JSONArray(s);
            List sorted = new ArrayList();
            List<JSONObject> obj2 = new ArrayList<JSONObject>();
            for (int i = 0; i < list.length(); i++) {
                obj2.add(list.getJSONObject(i));
            }

            Collections.sort( obj2, new Comparator<JSONObject>() {
                private static final String z = "datetime";
                @Override
                public int compare(JSONObject json_obj1, JSONObject json_obj2) {
                    String a = new String();
                    String b = new String();

                    try {
                        a = (String) json_obj1.get(z);
                        b = (String) json_obj2.get(z);
                    }
                    catch (Exception e) {}
                    return -a.compareTo(b);
                }
            });

            for (int i = 0; i < list.length(); i++) {
                sorted.add(obj2.get(i));
            }

            for (int i = 0; i < sorted.size(); i++) {
                JSONObject obj = (JSONObject) sorted.get(i);
                String title = obj.getString("title");
                String datetime = obj.getString("datetime");
                String notes = obj.getString("notes");
                notess.add(new newnote(notes, title, datetime));
            }

            return notess;
        } catch (Exception e) { return null; }
    }
    @Override
    protected String doInBackground(String... strings) {return read();}

    private String read()
    {
        try
        {
            InputStream is = ma.getApplicationContext().openFileInput("new_note.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            return new String(buffer, "UTF-8");
        } catch (FileNotFoundException e) { return null;
        } catch (Exception e) { return null; }
    }
}
