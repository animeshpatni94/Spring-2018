package com.animeshpatni.multinotepad;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class note extends AppCompatActivity {

    private EditText Note;
    private EditText Title;
    private int location;
    private String datetime;
    private newnote n;
    private Calendar calendar;
    private SimpleDateFormat sdf;
    private DateFormat df;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note);
        Title = findViewById(R.id.new_title);
        Note = findViewById(R.id.new_note);
        Note.setMovementMethod(new ScrollingMovementMethod());
        Intent intent = getIntent();
        if (intent.hasExtra(newnote.class.getName())) {
            n = (newnote) intent.getSerializableExtra(newnote.class.getName());
            Title.setText(n.getTitle());
            Note.setText(n.getNote());
            datetime = (String) intent.getSerializableExtra(n.getDatetime());
        }
        location = (Integer) intent.getSerializableExtra("");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.note_save, menu);
        return true;
    }

    public String formatdate(){
        String d1;
        Date date  = new Date(System.currentTimeMillis());
        calendar = Calendar.getInstance();
        df = DateFormat.getDateTimeInstance(DateFormat.DEFAULT,DateFormat.FULL, Locale.US);
        d1 = df.format(calendar.getTime());
        return d1;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save:
                Intent dd = new Intent();

                if (Title.getText().toString().trim().equals("")){
                    dd.putExtra("MESSAGE", "Can't save new notes without title");
                }
                else
                {
                    if (n != null && n.getTitle().equals(Title.getText().toString()) && n.getNote().equals(Note.getText().toString())){
                        dd.putExtra("DATETIME", n.getDatetime());
                    }else{
                        dd.putExtra("DATETIME", formatdate());
                    }
                    dd.putExtra("TITLE", Title.getText().toString());
                    dd.putExtra("NOTES", Note.getText().toString());
                }
                dd.putExtra("INDEX", location);
                setResult(RESULT_OK, dd);
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onBackPressed() {
        Intent dd = new Intent();
        if (Title.getText().toString().trim().equals("")){
            dd.putExtra("MESSAGE", "Can't save new notes without title");
        }
        if(n != null && (!(n.getTitle().equals(Title.getText().toString())) || !(n.getNote().equals(Note.getText().toString())))){
            show();
        }else if (n == null && (Title.getText().toString().length() > 0 || Note.getText().toString().length() > 0)){
            show();
        }else{
            super.onBackPressed();
        }
    }

    public void show(){
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setMessage("Note not saved! Do you want to save note '"+Title.getText().toString()+"'?");
        b.setIcon(R.drawable.ic_note_black_48dp);
        b.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Intent dd = new Intent();
                if (n != null && n.getTitle().equals(Title.getText().toString()) && n.getNote().equals(Note.getText().toString())){
                    dd.putExtra("DATETIME", n.getDatetime());
                }else{
                    dd.putExtra("DATETIME", formatdate());
                }
                dd.putExtra("INDEX", location);
                dd.putExtra("TITLE", Title.getText().toString());
                dd.putExtra("NOTES", Note.getText().toString());
                setResult(RESULT_OK, dd);
                finish();
            }
        });
        b.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                finish();
            }
        });
        AlertDialog dialog = b.create();
        dialog.show();
    }
}
