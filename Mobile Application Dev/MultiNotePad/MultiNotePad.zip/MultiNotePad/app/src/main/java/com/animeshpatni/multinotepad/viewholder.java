package com.animeshpatni.multinotepad;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by anime on 08-02-2018.
 */

public class viewholder extends RecyclerView.ViewHolder
{
    TextView note;
    TextView title;
    TextView dt;

    viewholder(View item)
    {
        super(item);

        note = item.findViewById(R.id.card_note);
        title = item.findViewById(R.id.card_title);
        dt = item.findViewById(R.id.card_date);
    }
}
