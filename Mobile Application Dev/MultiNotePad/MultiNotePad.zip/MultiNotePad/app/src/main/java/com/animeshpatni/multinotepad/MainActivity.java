package com.animeshpatni.multinotepad;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.DrawableRes;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.JsonWriter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {

    private static final int REQ = 1;
    private RecyclerView rv;
    private adapter adap;
    private List<newnote> listnote = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rv = findViewById(R.id.recycle);
        adap = new adapter(listnote, this);
        rv.setAdapter(adap);
        rv.setLayoutManager(new LinearLayoutManager(this));
        //rv.setAdapter(adap);
        loadfiles();
        new asyncsample(this).execute();
    }

    private void loadfiles() {
        File file = this.getFileStreamPath("new_note.json");
        if (!file.exists()) {
            try {
                FileOutputStream out = getApplicationContext().openFileOutput("new_note.json", Context.MODE_PRIVATE);
                OutputStreamWriter w = new OutputStreamWriter(out);
                w.write(" ");
                w.close();
            } catch (Exception e) {
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_icon, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.about:
                Intent intent_about = new Intent(this, about.class);
                startActivity(intent_about);
                return true;
            case R.id.add:
                Intent intent_add = new Intent(this, note.class);
                intent_add.putExtra("", -1);
                startActivityForResult(intent_add, REQ);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        json();
    }

    @Override
    public void onClick(View v) {
        int positions = rv.getChildAdapterPosition(v);
        newnote n = listnote.get(positions);
        Intent i = new Intent(MainActivity.this, note.class);
        i.putExtra("", positions);
        i.putExtra(newnote.class.getName(), n);
        startActivityForResult(i, REQ);
    }


    @Override
    public boolean onLongClick(View v) {
        final int positions = rv.getChildLayoutPosition(v);
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setMessage("Delete Note '" + listnote.get(positions).getTitle() + "'?");
        b.setIcon(R.drawable.ic_delete_black_48dp);
        b.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                listnote.remove(positions);
                adap.notifyDataSetChanged();
            }
        });
        b.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
            }
        });
        AlertDialog dialog = b.create();
        dialog.show();
        return false;
    }


    @Override
    public void onActivityResult(int request, int result, Intent d) {
        if (request == REQ && result == RESULT_OK) {
            if (d.hasExtra("MESSAGE")) {
                Toast.makeText(this, d.getStringExtra("MESSAGE"), Toast.LENGTH_SHORT).show();
            } else {
                String title = d.getStringExtra("TITLE");
                String datetime = d.getStringExtra("DATETIME");
                String note = d.getStringExtra("NOTES");
                int position = d.getIntExtra("INDEX", -1);
                if (position != -1 && listnote.size() > 0) {
                    newnote n = listnote.get(position);
                    n.setTitle(title);
                    n.setDatetime(datetime);
                    n.setNote(note);
                } else listnote.add(new newnote(note, title, datetime));
                json();
            }
        }
    }

    private void json() {
        try {
            FileOutputStream file_out_stream = getApplicationContext().openFileOutput("new_note.json", Context.MODE_PRIVATE);
            JsonWriter jw = new JsonWriter(new OutputStreamWriter(file_out_stream, "UTF-8"));
            jw.setIndent("  ");
            jw.beginArray();
            for (newnote n : this.listnote) {
                jw.beginObject();
                jw.name("title").value(n.getTitle());
                jw.name("datetime").value(n.getDatetime());
                jw.name("notes").value(n.getNote());
                jw.endObject();
            }
            jw.endArray();
            jw.close();
        } catch (Exception e) {
        }
    }

    public void getasyncdata(ArrayList<newnote> new_list) {
        if (new_list == null) return;
        adap.updateList(new_list);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadfiles();
        new asyncsample(this).execute();
    }
}


