package com.animeshpatni.multinotepad;

import java.io.Serializable;

/**
 * Created by anime on 06-02-2018.
 */

public class newnote implements Serializable
    {
        private String note;
        private String title;
        private String datetime;

        public newnote(String n,String t, String d)
        {
            note = n;
            title = t;
            datetime = d;
        }

        public String getDatetime() { return datetime; }

        public void setDatetime(String datetime) {
            this.datetime = datetime;
        }

        public String getNote() {
            return note;
        }

        public void setNote(String note) {
            this.note = note;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }
    }
