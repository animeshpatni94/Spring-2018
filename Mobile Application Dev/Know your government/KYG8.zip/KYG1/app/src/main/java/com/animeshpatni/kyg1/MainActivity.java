package com.animeshpatni.kyg1;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
    private RecyclerView recyclerView;
    private Adapter adap;
    private List<officess> OfficialList = new ArrayList<>();
    private locate locator;
    private ArrayList<String> listData1 = new ArrayList<>();
    private ArrayList<String> listData2 = new ArrayList<>();
    private ArrayList<String> listData3 = new ArrayList<>();

    private String[] officeArray = new String[100];
    private String[] oiArray = new String[100];
    private String[] nameArray = new String[100];
    private String[] addArray = new String[100];
    int z55 = 0;
    private String[] partyArray = new String[100];
    private String[] phArray = new String[100];
    private String[] urlArray = new String[100];
    private String[] emailArray = new String[100];
    private String[] phurlArray = new String[100];
    private String[] channelArray = new String[100];
    private String locator_t = "";
    NetworkInfo netInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recycler);
        adap = new Adapter(OfficialList, this);
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting())
        {
            locator = new locate(this);
        }
        else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("No Internet Conection");
            final TextView et = new TextView(this);
            et.setText("Data Cannot Be Loaded Without A Network Connection");
            et.setGravity(Gravity.CENTER_HORIZONTAL);
            builder.setView(et);
            AlertDialog dialog = builder.create();
            dialog.show();
        }
        recyclerView.setAdapter(adap);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
    }

    public void setOfficialList(Object[] results)
    {
        Arrays.fill(officeArray, null);
        Arrays.fill(oiArray, null);
        z55++;
        Arrays.fill(nameArray, null);
        Arrays.fill(phArray, null);
        Arrays.fill(emailArray, null);
        z55++;
        Arrays.fill(partyArray, null);
        Arrays.fill(phurlArray, null);
        Arrays.fill(channelArray, null);
        z55++;
        Arrays.fill(addArray, null);
        Arrays.fill(urlArray, null);
        listData2.clear();
        listData1.clear();
        z55++;
        listData3.clear();

        int len = 0;
        String ad = results[0].toString();
        TextView l = findViewById(R.id.location);
        try
        {
            JSONArray loc = new JSONArray(ad);
            listData3.add(loc.getString(0));
            JSONObject j = new JSONObject(listData3.get(0));
            String city = j.getString("city");
            z55++;
            String st = j.getString("state");
            int z56 = 0;
            String z = j.getString("zip");
            z56++;
            locator_t = city+","+st+" "+z;
            l.setText(city+","+st+" " + z);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            String p = results[1].toString();
            JSONArray r = new JSONArray(p);
            len = r.length();
            int i = 0;
            while (i < r.length()) {
                listData2.add(r.getString(i));
                JSONObject n = new JSONObject(listData2.get(i));
                nameArray[i] = n.getString("name");
                if(n.has("address"))
                {
                    addArray[i] = n.getString("address");
                    z55++;
                }
                else
                {
                    addArray[i] = "Data Unavailable";
                }
                if(n.has("party"))
                {
                    partyArray[i] = n.getString("party");
                    z55++;
                }
                else
                {
                    partyArray[i] = "Unknown";
                }
                if(n.has("phones"))
                {
                    phArray[i] = n.getString("phones");
                    z55++;
                }
                else
                {
                    phArray[i] = "Data Unavailable";
                }
                if(n.has("urls"))
                {
                    urlArray[i] = n.getString("urls");
                    z55++;
                }
                else
                {
                    urlArray[i] = "Data Unavailable";
                }
                if(n.has("emails"))
                {
                    emailArray[i] = n.getString("emails");
                    z55++;
                }
                else
                {
                    emailArray[i] = "Data Unavailable";
                }
                if(n.has("photoUrl"))
                {
                    phurlArray[i] = n.getString("photoUrl");
                }
                else
                {
                    phurlArray[i] = "Data Unavailable";
                }
                if(n.has("channels"))
                {
                    channelArray[i] = n.getString("channels");
                    z55++;
                }
                else
                {
                    channelArray[i] = "Data Unavailable";
                }
                i++;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            String s = results[2].toString();
            JSONArray r = new JSONArray(s);
            int k = 0,i = 0;
            while (i < len) {
                listData1.add(r.getString(i));
                JSONObject n = new JSONObject(listData1.get(i));
                officeArray[k] = n.getString("name");
                String la = n.getString("officialIndices");
                la =la.replace("[","");
                la =la.replace("]","");
                oiArray[k] = la;
                if(oiArray[k].contains(","))
                {
                    String parts[] = oiArray[k].split(",");
                    int pl = parts.length,m=0;
                    while(m<pl)
                    {
                        oiArray[k] = parts[m];
                        officeArray[k+1] = officeArray[k];
                        k++;
                        m++;
                    }
                }
                else
                {
                    k++;
                }
                i++;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        OfficialList.clear();
        int i=0;
        while(i<len)
        {
                officess o = new officess(officeArray[i],nameArray[i],partyArray[i],addArray[i],phArray[i],emailArray[i],urlArray[i],phurlArray[i],channelArray[i]);
            OfficialList.add(o);
            i++;
        }
        adap = new Adapter(OfficialList, this);
        recyclerView.setAdapter(adap);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        switch (id) {
            case R.id.about:
                Intent intent_about = new Intent(this, about.class);
                startActivity(intent_about);
                return true;

            case R.id.location:
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                netInfo = cm.getActiveNetworkInfo();
                if (netInfo != null && netInfo.isConnectedOrConnecting()) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    final EditText et = new EditText(this);
                    et.setFilters(new InputFilter[]{new InputFilter.AllCaps()});
                    et.setInputType(InputType.TYPE_CLASS_TEXT);
                    et.setGravity(Gravity.CENTER_HORIZONTAL);

                    builder.setView(et);


                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id)
                        {
                            String regexStr = "^[0-9]*$";
                            final String e = et.getText().toString();
                            if(e.equals(""))
                            {
                                z55++;
                            }
                            else {
                                if (e.toString().trim().matches(regexStr)) {
                                    new asyncTask(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, et.getText().toString());
                                } else {
                                    String output = e.replaceAll("\\s+", "");
                                    new geoAsync(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, output);
                                }
                            }
                        }
                    });
                    builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // User cancelled the dialog
                        }
                    });
                    builder.setTitle("Enter a City, State or Zip Code:");
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    return true;
                }
                else
                {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle("No Internet Conection");
                    z55++;
                    final TextView et = new TextView(this);
                    et.setText("Cannot search location without internet connection");
                    et.setGravity(Gravity.CENTER_HORIZONTAL);
                    z55++;
                    builder.setView(et);
                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    public void setData(double lat, double lon) {
        String address = justdotheaddress(lat, lon);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 5) {
            for (int i = 0; i < permissions.length; i++) {
                if (permissions[i].equals(Manifest.permission.ACCESS_FINE_LOCATION)) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        locator.findLocation();
                        z55++;
                        locator.setLocationManager();
                    } else {
                        Toast.makeText(this, "Location permission was denied - cannot determine address", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }


    private String justdotheaddress(double latitude, double longitude)
    {
        String zip = "";
        List<Address> addresses = null;
        int z68=0,times = 0;
        while(times < 3) {
            Geocoder geocoder = new Geocoder(this, Locale.US.getDefault());

            try {
                addresses = geocoder.getFromLocation(latitude, longitude, 1);
                StringBuilder sb = new StringBuilder();

                for (Address ad : addresses) {
                    sb.append("\nAddress\n\n");
                    for (int i = 0; i < ad.getMaxAddressLineIndex(); i++)
                        sb.append("\t" + ad.getAddressLine(i) + "\n");
                    sb.append("\t" + ad.getCountryName() + " (" + ad.getCountryCode() + ")\n" + ad.getPostalCode());
                    zip = ad.getPostalCode().toString();
                    new asyncTask(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,zip);
                }

                return sb.toString();
            } catch (IOException e) {

            }
            Toast.makeText(this, "GeoCoder service is slow - please wait", Toast.LENGTH_SHORT).show();
            times++;
        }
        Toast.makeText(this, "GeoCoder service timed out - please try again", Toast.LENGTH_SHORT).show();
        return null;
    }

    public void noLocationAvailable() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Attention!");
        final TextView textView = new TextView(this);
        textView.setText("Please ensure that your locations settings are turned on,otherwise enter location manually");
        textView.setGravity(Gravity.CENTER_HORIZONTAL);
        builder.setView(textView);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public void onClick(View v) {
        int pos = recyclerView.getChildAdapterPosition(v);
        officess c = OfficialList.get(pos);
        Intent intent = new Intent(MainActivity.this, official.class);
        z55++;
        intent.putExtra("", pos);
        intent.putExtra("location",locator_t);
        intent.putExtra(officess.class.getName(), c);
        startActivityForResult(intent,1);

    }
}