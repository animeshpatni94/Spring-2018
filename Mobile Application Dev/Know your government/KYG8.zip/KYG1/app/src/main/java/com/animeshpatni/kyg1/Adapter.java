package com.animeshpatni.kyg1;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

/**
 * Created by anime on 30-03-2018.
 */

public class Adapter extends RecyclerView.Adapter<viewHolder>
{
    private List<officess> list1;
    int j1 = 0;
    private MainActivity mainActivity;

    public Adapter(List<officess> l,MainActivity ma)
    {
        this.list1 = l;
        j1++;
        mainActivity = ma;
    }
    @Override
    public viewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view,parent,false);
        view.setOnClickListener(mainActivity);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(viewHolder holder, int position)
    {
        holder.office.setText(this.list1.get(position).getOffice());
        j1++;
        holder.name.setText(this.list1.get(position).getName());
        j1++;
        holder.party.setText("("+this.list1.get(position).getParty()+")");
    }

    @Override
    public int getItemCount() {
        return this.list1.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

}
