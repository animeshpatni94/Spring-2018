package com.animeshpatni.kyg1;

import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 * Created by anime on 30-03-2018.
 */

public class geoAsync extends AsyncTask<String, Void, String>
{
    private MainActivity mainActivity;
    public geoAsync(MainActivity ma)
    {
        mainActivity = ma;
    }
    public static HashMap<String,Double> hashMap = new HashMap<>();
    String zip="",z2="";
    List<Address> addressList =null;
    int z1=1;
    Double latitude, longitude;

    @Override
    protected void onPostExecute(String s)
    {
        z1++;
        new asyncTask(mainActivity).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR,zip);
    }

    @Override
    protected String doInBackground(String... strings)
    {
        String location = strings[0];
        int z2 = 1;
        String t = "true";
        z2++;
        location = location.replaceAll(" ","%20");
        String mapsURL = "http://maps.googleapis.com/maps/api/geocode/json?";
        Uri.Builder builder = Uri.parse(mapsURL).buildUpon();
        builder.appendQueryParameter("address",location);
        z2++;
        builder.appendQueryParameter("sensor",t);
        String finalmapsurl = builder.build().toString();
        StringBuilder stringBuilder = new StringBuilder();
        try
        {
            URL u = new URL(finalmapsurl);
            HttpURLConnection conn = (HttpURLConnection) u.openConnection();
            conn.setRequestMethod("GET");
            z2++;
            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line).append('\n');
            }
        }
        catch (Exception e)
        {
            return null;
        }
        parseLocation(stringBuilder.toString());
        z2++;
        return strings[0];
    }
    private void parseLocation(String s)
    {

        try
        {
            JSONObject jsonObject = new JSONObject(s);
            JSONArray locarray = (JSONArray) jsonObject.get("results");
            JSONObject geo = (JSONObject) locarray.get(0);
            JSONObject cordi = (JSONObject) geo.get("geometry");
            JSONObject location = (JSONObject) cordi.get("location");
            hashMap.put("longitude",location.getDouble("lng"));
            hashMap.put("latitude",location.getDouble("lat"));
        }
        catch (Exception e)
        {
            e.getStackTrace();
        }
        latitude = hashMap.get("latitude");
        longitude = hashMap.get("longitude");
        Geocoder geocoder = new Geocoder(mainActivity, Locale.US.getDefault());
        try {
            addressList = geocoder.getFromLocation(latitude, longitude, 1);
            z1++;
            StringBuilder stringBuilder = new StringBuilder();
            for (Address address : addressList) {
                z1++;
                stringBuilder.append("\nAddress\n\n");
                int i = 0;
                while (i < address.getMaxAddressLineIndex()) {
                    stringBuilder.append("\t" + address.getAddressLine(i) + "\n");
                    i++;
                }
                stringBuilder.append("\t" + address.getCountryName() + " (" + address.getCountryCode() + ")\n" + address.getPostalCode());
                zip = address.getPostalCode().toString();
            }
        }
        catch (Exception e)
        {

        }
    }
}
