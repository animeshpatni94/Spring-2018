package com.animeshpatni.kyg1;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class photo extends AppCompatActivity {

    private ImageView imageView;
    String url = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);
        TextView tloc = findViewById(R.id.plocation);
        TextView o = findViewById(R.id.office);
        TextView n = findViewById(R.id.name);
        imageView = findViewById(R.id.photo1);
        Intent Lintent = getIntent();
        if (Lintent.hasExtra("location")) {
            String ofL = Lintent.getSerializableExtra("location").toString();
            tloc.setText(ofL);
        }
        //Official ni;
        Intent intent = getIntent();
        if (intent.hasExtra("name")) {
            String na = intent.getSerializableExtra("name").toString();
            n.setText(na);
        }

        Intent intent1 = getIntent();
        if (intent1.hasExtra("office")) {
            String of = intent.getSerializableExtra("office").toString();
            o.setText(of);
        }

        Intent intent2 = getIntent();
        if(intent2.hasExtra("party")) {
            String p = intent.getSerializableExtra("party").toString();
            if (p.equals("Republican")) {
                getWindow().getDecorView().setBackgroundColor(Color.RED);
            } else if (p.equals("Democratic")) {
                getWindow().getDecorView().setBackgroundColor(Color.BLUE);
            } else {
                getWindow().getDecorView().setBackgroundColor(Color.BLACK);
            }
        }

        Intent p = getIntent();
        if (p.hasExtra("url")) {
            url = intent.getSerializableExtra("url").toString();

            if (url != null) {
                Picasso picasso = new Picasso.Builder(this).listener(new Picasso.Listener() {
                    @Override
                    public void onImageLoadFailed(Picasso picasso, Uri uri, Exception exception) {
                        final String changedUrl = url.replace("http:", "https:");
                        picasso.load(changedUrl)
                                .error(R.drawable.brokenimage)
                                .placeholder(R.drawable.placeholder)
                                .into(imageView);
                    }
                }).build();
                if(!url.equals("Data Unavailable")) {
                    picasso.load(url)
                            .error(R.drawable.brokenimage)
                            .placeholder(R.drawable.placeholder)
                            .into(imageView);
                }
            } else {
                Picasso.with(this).load(url)
                        .error(R.drawable.brokenimage)
                        .placeholder(R.drawable.missingimage)
                        .into(imageView);
            }
        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.photo_menu, menu);
        return true;
    }
}
