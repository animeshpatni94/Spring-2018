package com.animeshpatni.kyg1;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

/**
 * Created by anime on 30-03-2018.
 */

public class viewHolder extends RecyclerView.ViewHolder
{
    public TextView office;
    public  TextView party;
    public  TextView name;
    public viewHolder(View view)
    {
        super(view);
        office = view.findViewById(R.id.office);
        party = view.findViewById(R.id.party);
        name = view.findViewById(R.id.name);
    }

}
