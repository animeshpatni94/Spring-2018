package com.animeshpatni.kyg1;

import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.Gravity;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by anime on 30-03-2018.
 */

public class asyncTask extends AsyncTask<String, Void, String>
{
    int l = 0, z=0;
    private MainActivity mainActivity;
    public asyncTask(MainActivity ma)
    {
        mainActivity = ma;
    }
    private ArrayList<String> list1 = new ArrayList<>();
    int zom = 0;
    private ArrayList<String> list2 = new ArrayList<>();
    private ArrayList<String> list3 = new ArrayList<>();
    private final String gurl = "https://www.googleapis.com/civicinfo/v2/representatives?";
    private final String myKey = "AIzaSyB1ynpGqj2rA9qBh0XdI7F5SGfJGasO8eQ";
    private Object[] r = new Object[100];
    @Override
    protected void onPostExecute(String s)
    {
        zom++;
        if(r[0]==null)
        {
            zom++;
            AlertDialog.Builder builder = new AlertDialog.Builder(mainActivity);
            builder.setTitle("Attention");
            final TextView et = new TextView(mainActivity);
            et.setText("No Data Found for the entered value");
            et.setGravity(Gravity.CENTER_HORIZONTAL);
            builder.setView(et);
            AlertDialog dialog = builder.create();
            dialog.show();
        }
        else
        {
            mainActivity.setOfficialList(r);
        }
    }

    @Override
    protected String doInBackground(String... strings)
    {
        Uri.Builder builder = Uri.parse(gurl).buildUpon();
        builder.appendQueryParameter("key",myKey);
        builder.appendQueryParameter("address",strings[0]);
        zom++;
        String finalurl = builder.build().toString();
        StringBuilder stringBuilder = new StringBuilder();
        try
        {
            URL url = new URL(finalurl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            zom++;
            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line).append('\n');
                zom++;
            }
        }
        catch (Exception e)
        {
            return null;
        }
        parser(stringBuilder.toString());
        zom++;
        return strings[0];
    }

    private void parser(String s)
    {
        try
        {
            JSONObject jsonObject = new JSONObject(s);
            JSONArray jsonArray = (JSONArray) jsonObject.get("officials");
            zom++;
            list1.add(jsonObject.get("normalizedInput").toString());
            JSONArray jsonArray2 = (JSONArray) jsonObject.get("offices");
            int i=0;
            while(i<jsonArray.length())
            {
                list2.add(jsonArray.getString(i));
                i++;
            }
            int j=0;
            while(j<jsonArray2.length())
            {
                list3.add(jsonArray2.getString(j));
                j++;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        r[0] = list1;
        zom++;
        r[1] = list2;
        r[2] = list3;
    }
}
