package com.animeshpatni.stockapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener,View.OnLongClickListener {

    private String symbol = "";
    private String company = "";
    private static final String TAG = "MainActivity";
    private String s = "";
    private RecyclerView cardview;
    private SwipeRefreshLayout swiper;
    private Adapter myadap;
    private database db;
    private List<new_note> invest = new ArrayList<>();
    NetworkInfo networkInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cardview = findViewById(R.id.recycler);
        myadap = new Adapter(invest, this);
        db = new database(this);
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        networkInfo = cm.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
            List<String[]> l = db.loadStocks();
            for (int i = 0; i < l.size(); i++) {
                String gets = l.get(i)[0];
                String getc = l.get(i)[1];
                new async(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, gets, "Load", getc);
            }
        } else {
            AlertDialog.Builder b = new AlertDialog.Builder(this);
            b.setIcon(R.drawable.ic_error_black_24dp);
            b.setTitle("No Internet Connection");
            final TextView textView = new TextView(this);
            textView.setText("Stocks Cannot Be Loaded Without Internet Connection");
            textView.setGravity(Gravity.CENTER_HORIZONTAL);
            b.setView(textView);
            AlertDialog alertDialog = b.create();
            alertDialog.show();
        }
        cardview.setAdapter(myadap);
        cardview.setLayoutManager(new LinearLayoutManager(this));
        swiper = findViewById(R.id.swiper);
        swiper.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refresh();
            }
        });
    }

    private void refresh() {
        invest.clear();
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        networkInfo = cm.getActiveNetworkInfo();
        swiper.setRefreshing(false);
        if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
            List<String[]> l = db.loadStocks();
            for (int i = 0; i < l.size(); i++) {
                String gets = l.get(i)[0];
                String getc = l.get(i)[1];
                new async(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, gets, "Load", getc);
            }
        } else {
            AlertDialog.Builder b = new AlertDialog.Builder(this);
            b.setIcon(R.drawable.ic_error_black_24dp);
            b.setTitle("No Internet Connection");
            final TextView textView = new TextView(this);
            textView.setText("Stocks Cannot Be Updated Without Internet Connection");
            textView.setGravity(Gravity.CENTER_HORIZONTAL);
            b.setView(textView);
            AlertDialog alertDialog = b.create();
            alertDialog.show();
        }
    }

    @Override
    public boolean onLongClick(View view) {
        final int position = cardview.getChildLayoutPosition(view);
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i)
            {
                Log.d(TAG, "Deleting Stock: "+position);
                db.deleteStock(invest.get(position).getSymbol());
                invest.remove(position);
                myadap.notifyDataSetChanged();
                cardview.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.setIcon(R.drawable.ic_delete_black_24dp);
        builder.setTitle("Delete Stock "+invest.get(position).getSymbol()+" ?");
        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        return false;
    }

    @Override
    public void onClick(View view) {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        networkInfo = cm.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnectedOrConnecting())
        {
            int position = cardview.getChildLayoutPosition(view);
            new_note s = invest.get(position);
            String URL = "http://www.marketwatch.com/investing/stock/";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            Uri.Builder builder = Uri.parse(URL).buildUpon();
            builder.appendPath(s.getSymbol());
            URL = builder.toString();
            intent.setData(Uri.parse(URL));
            startActivity(intent);
        }
        else
        {
            Toast.makeText(this,"No Internet Connection",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.About:
                Intent intent_about = new Intent(this, about_activity.class);
                startActivity(intent_about);
                return true;

            case R.id.add_stock:
                //Toast.makeText(this, "Welcome", Toast.LENGTH_SHORT).show();
                ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                networkInfo = cm.getActiveNetworkInfo();
                if (networkInfo != null && networkInfo.isConnectedOrConnecting()) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    final EditText editText = new EditText(this);
                    editText.setFilters(new InputFilter[]{new InputFilter.AllCaps()});
                    editText.setInputType(InputType.TYPE_CLASS_TEXT);
                    editText.setGravity(Gravity.CENTER_HORIZONTAL);
                    builder.setView(editText);
                    builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            s = editText.getText().toString();
                            new async(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, s, "Stock");
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                        }
                    });
                    builder.setIcon(R.drawable.ic_add_circle_black_24dp);
                    builder.setMessage("Stock Selection");
                    builder.setTitle("Please enter a stock symbol: ");
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setIcon(R.drawable.ic_error_black_24dp);
                    builder.setTitle("No Internet Connection");
                    final TextView textView = new TextView(this);
                    textView.setText("Stocks Cannot Be Added Without A Network Connection");
                    textView.setGravity(Gravity.CENTER_HORIZONTAL);
                    builder.setView(textView);
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();
                }
                return true;
            default:
                //Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
                return super.onOptionsItemSelected(item);
        }
        //return true;
    }

    public void newsym(HashMap<String, String> list) {
        List<String[]> l = db.loadStocks();
        Log.d(TAG, "newsym: "+list);
        int f = 0;
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i)[0].compareTo(list.get("SYMBOL")) == 0) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Duplicate Stock");
                final TextView textView = new TextView(this);
                textView.setText("Stock symbol " + list.get("SYMBOL") + " is already displayed.");
                textView.setGravity(Gravity.CENTER_HORIZONTAL);
                builder.setView(textView);
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                f = 1;
            }
        }
        if (f == 0) {
            new_note s = new new_note(list.get("SYMBOL"), list.get("COMPANY"));
            db.addStock(s);
            symbol = list.get("SYMBOL");
            company = list.get("COMPANY");
            Log.d(TAG, "newsym: "+company);
            new async(MainActivity.this).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, symbol, "Finance");
        }
    }

    public void updatedata(HashMap<String, String> w, HashMap<String, String> t, HashMap<String, Double> wfData) {
        {
            new_note stock = new new_note(w.get("SYMBOL"), w.get("COMPANY"), wfData.get("PRICE"), wfData.get("AMOUNT"), wfData.get("PERCENT"));
            invest.add(stock);
            Collections.sort(invest, new Comparator<new_note>() {
                @Override
                public int compare(new_note a, new_note b) {
                    String valA = "", valB = "";
                    try {
                        valA = a.getSymbol();
                        valB = b.getSymbol();
                    } catch (Exception e) {}
                    return -valB.compareTo(valA);
                }
            });
            myadap = new Adapter(invest, this);
            cardview.setLayoutManager(new LinearLayoutManager(this));
        }
    }
    public void deletedb(String s)
    {
        List<String[]> l = db.loadStocks();
        for (int i = 0; i < l.size(); i++)
        {
            if(l.get(i)[0].compareTo(s) == 0)
            {
                db.deleteStock(s);
                //invest.remove(i);
            }
        }
    }
}
