package com.animeshpatni.stockapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by anime on 27-02-2018.
 */

public class async extends AsyncTask<String,Void ,String>
{
    private static final String TAG = "async";
    private MainActivity ma;
    public String symbol = "";
    public String company = "";
    private String invalid = "";
    private database db;
    private  String check = "";
    public static HashMap<String, String> stockdata = new HashMap<>();
    public static HashMap<String, String> stockdata1 = new HashMap<>();
    public static HashMap<String, String> tickerdata = new HashMap<>();
    public static HashMap<String, String> loadata = new HashMap<>();
    public HashMap<String, Double> financialdata = new HashMap<>();
    private final String[] array=new String[1000];
    private int position=-1,len=0,len1=0;
    int flag = -2;
    private final String stock= "http://d.yimg.com/aq/autoc?region=US&lang=en-US";
    private final String finance = "https://api.iextrading.com/1.0/stock/";

    public async(MainActivity ma1)
    {
        ma=ma1;
    }

    @Override
    protected String doInBackground(String... strings)
    {
        check = strings[1];
        invalid = strings[0];
        Log.d(TAG, "doInBackground: "+ strings[1]);
        if(strings[1].equals("Stock"))
        {
            Uri.Builder builder =Uri.parse(stock).buildUpon();
            builder.appendQueryParameter("query",strings[0]);
            String finalurl = builder.build().toString();
            Log.d(TAG, "doInBackground: "+ finalurl);
            StringBuilder stringBuilder = new StringBuilder();
            //Log.d(TAG, "doInBackground: URL"+ stringBuilder);
            try
            {
                URL url = new URL(finalurl);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("GET");
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                //String single = bufferedReader.readLine();
                //Log.d(TAG, "doInBackground: "+single);
                String single;
                while((single = bufferedReader.readLine())!=null)
                {
                    stringBuilder.append(single).append('\n');
                }
                Log.d(TAG, "doInBackground: " + stringBuilder);
            }
            catch (Exception e)
            {
                Log.d(TAG, "doInBackground: ",e);
                return null;
            }
            parseJSON(stringBuilder.toString());
        }
        else if(strings[1].equals("Finance"))
        {
            Uri.Builder builder = Uri.parse(finance).buildUpon();
            String NewSeg = strings[0]+"/"+"quote";
            //Log.d(TAG, "NewSeg: "+NewSeg);
            builder.appendPath(NewSeg);
            String finalurl =builder.build().toString();
            Log.d(TAG, "FinURL: "+ finalurl);
            StringBuilder stringBuilder = new StringBuilder();
            try
            {
                URL url = new URL(finalurl);
                HttpsURLConnection httpURLConnection = (HttpsURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("GET");
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String single;
                while((single = bufferedReader.readLine())!=null)
                {
                    stringBuilder.append(single).append('\n');
                }
            }
            catch (Exception e)
            {
                Log.d(TAG, "doInBackground: Finanace",e);
                return null;
            }
            parseJSON(stringBuilder.toString());
        }
        else if(strings[1].equals("Load"))
        {
            symbol = strings[0];
            company = strings[2];
            Uri.Builder builder = Uri.parse(finance).buildUpon();
            String NewSeg = strings[0]+"/"+"quote";
            //Log.d(TAG, "NewSeg: "+NewSeg);
            builder.appendPath(NewSeg);
            String finalurl =builder.build().toString();
            //Log.d(TAG, "FinURL: "+ finalurl);
            StringBuilder stringBuilder = new StringBuilder();
            try
            {
                URL url = new URL(finalurl);
                HttpsURLConnection httpURLConnection = (HttpsURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("GET");
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String single;
                while((single = bufferedReader.readLine())!=null)
                {
                    stringBuilder.append(single).append('\n');
                }
            }
            catch (Exception e)
            {
                Log.d(TAG, "doInBackground: "+e);
                return null;
            }
            parseJSON(stringBuilder.toString());
        }
        return strings[1];
    }

    private void parseJSON(String s)
    {
        Log.d(TAG, "parseJSON: "+check);
        Log.d(TAG, "parseJSON: "+s);

        if(check.equals("Stock"))
        {
            try
            {
                JSONObject object = new JSONObject(s);
                Log.d(TAG, "parseJSON234: "+object);
                JSONObject obj  = object.getJSONObject("ResultSet");
                Log.d(TAG, "parseJSON567: "+obj);
                JSONArray jsonArray = obj.getJSONArray("Result");
                len1 = jsonArray.length();
                //len = 0;
                Log.d(TAG, "Array: "+len1);
                for(int i=0;i<len1;i++)
                {
                    JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                    Log.d(TAG, "parseJSON4545545454: "+ jsonObject);
                    stockdata.put("SYMBOL",jsonObject.getString("symbol"));
                    int w = jsonObject.getString("symbol").indexOf('.');
                    Log.d(TAG, "IndexOf: "+w);
                    stockdata.put("COMPANY",jsonObject.getString("name"));
                    Log.d(TAG, "parseJSON: "+stockdata);
                    String z = jsonObject.getString("type");
                    Log.d(TAG, "Type: "+z);
                    if(z.equals("S") && w==-1)
                    {
                        array[len] = stockdata.get("SYMBOL")+ " :- " +stockdata.get("COMPANY");
                        stockdata1.put("SYMBOL",jsonObject.getString("symbol"));
                        stockdata1.put("COMPANY",jsonObject.getString("name"));
                        len++;
                        Log.d(TAG, "Len "+len);
                        //Log.d(TAG, "parseJSON9487   : "+array[len]);
                    }
                }
            }
            catch (Exception e){
                Log.d(TAG, "parseJSON: ",e);
            }
        }
        else if(check.equals("Finance"))
        {
            try
            {
                JSONObject object = new JSONObject(s);
                Log.d(TAG, "parseJSON: Fin"+s);
                Log.d(TAG, "Fin Parse: "+object);
                tickerdata.put("SYM", object.getString("symbol"));
                financialdata.put("PRICE", object.getDouble("latestPrice"));
                financialdata.put("AMOUNT", object.getDouble("change"));
                financialdata.put("PERCENT", object.getDouble("changePercent"));
            }
            catch (Exception e) {
                Log.d(TAG, "parseJSON: ",e);
            }
        }else if(check.equals("Load"))
        {
            Log.d(TAG, "loadJSON: "+s);
            try
            {
                JSONObject object = new JSONObject(s);
                Log.d(TAG, "LoadJSON: " + object);
                //JSONObject object = (JSONObject) data1.get(0);
                tickerdata.put("SYM", object.getString("symbol"));
                financialdata.put("PRICE", object.getDouble("latestPrice"));
                financialdata.put("AMOUNT", object.getDouble("change"));
                financialdata.put("PERCENT", object.getDouble("changePercent"));
            }
            catch (Exception e) {
                Log.d(TAG, "parseJSON: "+e);
            }
        }
    }

    @Override
    protected void onPostExecute(String s)
    {
        if(check.equals("Stock"))
        {
            if(len == 0)
            {
                AlertDialog.Builder builder = new AlertDialog.Builder(ma);
                builder.setIcon(R.drawable.ic_error_black_24dp);
                builder.setTitle("Symbol Not Found: "+invalid);
                final TextView textView = new TextView(ma);
                textView.setText("Data for stock symbol not found");
                textView.setGravity(Gravity.CENTER_HORIZONTAL);
                builder.setView(textView);
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                Toast.makeText(ma,"Invalid Company Symbol",Toast.LENGTH_SHORT).show();
            }
            else if (len == 1)
            {
                Log.d(TAG, "onPostExecute: HI");
                ma.newsym(stockdata1);
            }
            else if(len>1)
            {
                Log.d(TAG, "onPostExecute: BYE");
                final String[] newarray = new String[len];
                for(int j=0;j<len;j++)
                {
                    newarray[j] = array[j];
                }
                AlertDialog.Builder builder1 = new AlertDialog.Builder(ma);
                //Log.d(TAG, "onPostExecute: "+ position);
                //String[] whatever = array[position].split("-");
                //Log.d(TAG, "onPostExecute: "+whatever[1]);
                Log.d(TAG, "onPostExecute: "+len);
                Log.d(TAG, "onPostExecute: "+array[len-1]);
                builder1.setIcon(R.drawable.ic_add_circle_black_24dp);
                builder1.setTitle("Make a selection:");
                builder1.setItems(newarray, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.d(TAG, "onPostExecute: ");
                        String[] whatever = newarray[i].split(" :- ");
                        loadata.put("SYMBOL",whatever[0].trim());
                        loadata.put("COMPANY",whatever[1].trim());
                        Log.d(TAG, "onClick: "+whatever[0]);
                        ma.newsym(loadata);
                        Log.d(TAG, "onClick: "+loadata);
                        Toast.makeText(ma,newarray[i],Toast.LENGTH_SHORT).show();
                    }
                });
                builder1.setNegativeButton("Nevermind", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });
                AlertDialog alertDialog = builder1.create();
                alertDialog.show();
            }
        }
        else if(check.equals("Finance"))
        {
            Log.d(TAG, "loaddata " + loadata + stockdata1 + tickerdata);
            if (loadata.isEmpty() == false)
            {
                stockdata1 = loadata;
            }
            else if(loadata.isEmpty())
            {
                loadata = stockdata1;
            }
            if (loadata.get("SYMBOL").equals(tickerdata.get("SYM")) == false)
            {
                Log.d(TAG, "todelete: "+loadata.get("SYMBOL"));
                AlertDialog.Builder builder = new AlertDialog.Builder(ma);
                builder.setIcon(R.drawable.ic_error_black_24dp);
                builder.setTitle("Finance Data Not Found: " + loadata.get("SYMBOL"));
                final TextView textView = new TextView(ma);
                textView.setText("Complete data for the stock symbol is not availabe");
                textView.setGravity(Gravity.CENTER_HORIZONTAL);
                builder.setView(textView);
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                Toast.makeText(ma, "Not Availabe", Toast.LENGTH_SHORT).show();
                ma.deletedb(loadata.get("SYMBOL"));
            }
            else
            {
                ma.updatedata(stockdata1, tickerdata, financialdata);
            }
        }
        else if(check.equals("Load")) {
            loadata.put("SYMBOL", symbol);
            loadata.put("COMPANY", company);
            stockdata1 = loadata;
            Log.d(TAG, "Tickerdata on load" + tickerdata);
            ma.updatedata(stockdata1, tickerdata, financialdata);
        }
    }
}
