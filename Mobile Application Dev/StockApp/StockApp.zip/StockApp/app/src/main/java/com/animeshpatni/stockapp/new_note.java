package com.animeshpatni.stockapp;

import java.io.Serializable;

/**
 * Created by anime on 27-02-2018.
 */

public class new_note implements Serializable
{
    private String Symbol;
    private String Company;
    private Double Price;
    private Double Change;
    private Double Percent;

    public new_note(String symbol, String company) {
        Symbol = symbol;
        this.Company = company;
    }

    public new_note(String symbol, String company, Double price, Double change, Double percent) {
        Symbol = symbol;
        this.Company = company;
        Price = price;
        Change = change;
        Percent = percent;
    }
    @Override
    public String toString() {
        return "new_note{" +
                "symbol='" + Symbol + '\'' +
                ", company='" + Company + '\'' +
                ", price=" + Price +
                ", change=" + Change +
                ", percent=" + Percent +
                '}';
    }

    public String getSymbol() {
        return Symbol;
    }

    public void setSymbol(String symbol) {
        Symbol = symbol;
    }

    public String getCompany() {
        return Company;
    }

    public void setCompany(String company) {
        this.Company = company;
    }

    public Double getPrice() {
        return Price;
    }

    public void setPrice(Double price) {
        Price = price;
    }

    public Double getChange() {
        return Change;
    }

    public void setChange(Double change) {
        Change = change;
    }

    public Double getPercent() {
        return Percent;
    }

    public void setPercent(Double percent) {
        Percent = percent;
    }
}
