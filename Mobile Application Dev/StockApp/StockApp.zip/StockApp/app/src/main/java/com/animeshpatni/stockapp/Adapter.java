package com.animeshpatni.stockapp;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.text.DecimalFormat;
import java.util.List;

/**
 * Created by anime on 27-02-2018.
 */

public class Adapter extends RecyclerView.Adapter<viewholder> {
    private MainActivity ma;
    private List<new_note> l;
    private static final String TAG = "Adapter";

    public Adapter(List<new_note> list_s, MainActivity ma1)
    {
        this.l = list_s;
        ma=ma1;
    }
    @Override
    public viewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view,parent,false);
        view.setOnClickListener(ma);
        view.setOnLongClickListener(ma);
        return new viewholder(view);
    }

    @Override
    public void onBindViewHolder(viewholder holder, int position) {
        Double stockprice = this.l.get(position).getChange();
        Log.d(TAG, "onBindViewHolder: "+l);
        DecimalFormat df= new DecimalFormat("#.##");
        if(stockprice<0)
        {
            holder.symbol.setText(this.l.get(position).getSymbol());
            holder.symbol.setTextColor(Color.RED);
            holder.company.setText(this.l.get(position).getCompany());
            holder.company.setTextColor(Color.RED);
            holder.price.setText(String.valueOf(this.l.get(position).getPrice()));
            holder.price.setTextColor(Color.RED);
            holder.amount.setText(String.valueOf(this.l.get(position).getChange()));
            holder.amount.setTextColor(Color.RED);
            String y = String.format("%.2f",this.l.get(position).getPercent());
            double j = this.l.get(position).getPercent();
            j = Math.round((j*100)/100);
            Log.d(TAG, "onBindViewHolder: Round of"+y);
            holder.percent.setText("( "+y+"% )");
            holder.percent.setTextColor(Color.RED);
            holder.sym.setText("▼ ");
            holder.sym.setTextColor(Color.RED);
        }
        else
        {
            holder.symbol.setText(this.l.get(position).getSymbol());
            holder.symbol.setTextColor(Color.GREEN);
            holder.company.setText(this.l.get(position).getCompany());
            holder.company.setTextColor(Color.GREEN);
            holder.price.setText(String.valueOf(this.l.get(position).getPrice()));
            holder.price.setTextColor(Color.GREEN);
            holder.amount.setText(String.valueOf(this.l.get(position).getChange()));
            holder.amount.setTextColor(Color.GREEN);
            String y = String.format("%.2f",this.l.get(position).getPercent());
            double j = this.l.get(position).getPercent();
            j = Math.round((j*100)/100);
            Log.d(TAG, "onBindViewHolder: Round of"+y);
            holder.percent.setText("( "+y+"% )");
            holder.percent.setTextColor(Color.GREEN);
            holder.sym.setText("▲ ");
            holder.sym.setTextColor(Color.GREEN);
        }
    }

    @Override
    public int getItemCount() {
        return this.l.size();
    }
}
