package com.animeshpatni.stockapp;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

/**
 * Created by anime on 27-02-2018.
 */

public class viewholder extends RecyclerView.ViewHolder
{
    public TextView symbol, company,price,sym,amount,percent;
    public viewholder(View itemView)
    {
        super(itemView);
        symbol = itemView.findViewById(R.id.symbol);
        company = itemView.findViewById(R.id.name);
        price = itemView.findViewById(R.id.price);
        sym = itemView.findViewById(R.id.sym);
        amount = itemView.findViewById(R.id.amount);
        percent = itemView.findViewById(R.id.percent);
    }
}
