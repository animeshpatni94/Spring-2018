package com.animeshpatni.asta;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.Externalizable;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static java.text.DateFormat.*;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_FILE = "Asta";
    private Calendar calendar;
    private SimpleDateFormat sdf;
    private DateFormat df;
    private String d1;
    private static final String TAG = "MainActivity";
    private EditText n;
    private product quickn;
    private TextView d;
    private SharedPreferences.Editor mEditor;
    private SharedPreferences mShared;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        d = (TextView)findViewById(R.id.date);
        n = (EditText)findViewById(R.id.note);
        n.setMovementMethod(new ScrollingMovementMethod());
        n.setTextIsSelectable(true);
        d = (TextView)findViewById(R.id.date);
        mShared = getSharedPreferences(PREFS_FILE,Context.MODE_PRIVATE);
        mEditor = mShared.edit();
        calendar = Calendar.getInstance();
        df = DateFormat.getDateTimeInstance(DateFormat.DEFAULT,DateFormat.FULL, Locale.US);
        d1 = df.format(calendar.getTime());
        String edit = mShared.getString("time","");
        if(edit == "")
        {
            d.setText(d1);
        }
        else
        {
            d.setText(edit);
        }
    }


    private product loadFile()
    {
        Log.d(TAG, "loadFile: ");
        quickn = new product();
        try {
            InputStream in = getApplicationContext().openFileInput("product.ser");
            ObjectInputStream ois = new ObjectInputStream(in);
            quickn = (product) ois.readObject();
            ois.close();
            ois.close();
        }
        catch (ClassNotFoundException e)
        {
            Toast.makeText(this, "No Notes Found", Toast.LENGTH_SHORT).show();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return quickn;
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        quickn = loadFile();
        if(quickn!=null)
        {
            n.setText(quickn.getd());
        }
    }
    @Override
    protected void onPause()
    {
        super.onPause();
        quickn.setd(n.getText().toString());
        notesaved();
        calendar = Calendar.getInstance();
        df = DateFormat.getDateTimeInstance(DateFormat.DEFAULT,DateFormat.FULL, Locale.US);
        d1 = df.format(calendar.getTime());
        d.setText("Last Updated At: "+d1);
        mEditor.putString("time",d.getText().toString());
        mEditor.apply();

    }
    private void notesaved()
    {
        Log.d(TAG, "notesaved: ");
        try
        {
            FileOutputStream fos = getApplicationContext().openFileOutput("product.ser", Context.MODE_PRIVATE);
            ObjectOutputStream ois =new ObjectOutputStream(fos);
            ois.writeObject(quickn);
            ois.flush();
            fos.close();
            Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show();
        }
        catch (Exception e)
        {
            e.getStackTrace();
        }
    }
    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        super.onSaveInstanceState(outState);
        outState.putString("DATE", d.getText().toString());
    }
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        d.setText(savedInstanceState.getString("DATE"));
    }
}


