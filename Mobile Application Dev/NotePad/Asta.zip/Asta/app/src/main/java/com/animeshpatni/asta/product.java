package com.animeshpatni.asta;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * Created by anime on 30-01-2018.
 */

public class product implements Externalizable
{
    private String quickn;
    public String date;
    private static final long serialVersionUID = 11;
    private static final byte INTERNAL_VERSION =1;

    public String getd()
    {
        return quickn;
    }
    public void setd(String d)
    {
        this.quickn = d;
    }

   /* public void setDate(String date)
    {
        this.date=date;
    }

    public String getDate()
    {
        return date;
    }

    @Override
    public String toString()
    {
        return "quicknote{" + "date='" + date + '\'' + ", note='" + quickn + '\'' + '}';
    }*/

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException
    {
        int bersion = in.readByte();
        quickn = (String) in.readObject();
    }

    @Override
    public void writeExternal(ObjectOutput out) throws IOException
    {
        out.write(INTERNAL_VERSION);
        out.writeObject(quickn);
    }


}

